-- Migration: 053_restore_core_foreign_keys.sql
-- Description: Re-add the 13 foreign keys referencing products/stores/categories/users
--              that were lost on databases where archive/001_create_tables.sql was
--              executed. Its DROP TABLE ... CASCADE on those four tables destroyed
--              every inbound FK on the 7 tables it does not recreate, and the
--              guarded DDL that followed (CREATE TABLE IF NOT EXISTS /
--              ADD COLUMN IF NOT EXISTS ... REFERENCES) never rebuilt them.
--              Fresh installs already have all 13, so this is a no-op there.
-- Created: 2026-09-28

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'import_jobs'::regclass AND conname = 'import_jobs_store_id_fkey') THEN
        ALTER TABLE import_jobs ADD CONSTRAINT import_jobs_store_id_fkey
            FOREIGN KEY (store_id) REFERENCES stores(id);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'import_jobs'::regclass AND conname = 'import_jobs_user_id_fkey') THEN
        ALTER TABLE import_jobs ADD CONSTRAINT import_jobs_user_id_fkey
            FOREIGN KEY (user_id) REFERENCES users(id);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'pricing_rules'::regclass AND conname = 'pricing_rules_category_id_fkey') THEN
        ALTER TABLE pricing_rules ADD CONSTRAINT pricing_rules_category_id_fkey
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'pricing_rules'::regclass AND conname = 'pricing_rules_product_id_fkey') THEN
        ALTER TABLE pricing_rules ADD CONSTRAINT pricing_rules_product_id_fkey
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'pricing_rules'::regclass AND conname = 'pricing_rules_store_id_fkey') THEN
        ALTER TABLE pricing_rules ADD CONSTRAINT pricing_rules_store_id_fkey
            FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE SET NULL;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'product_stock'::regclass AND conname = 'product_stock_product_id_fkey') THEN
        ALTER TABLE product_stock ADD CONSTRAINT product_stock_product_id_fkey
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'product_stock'::regclass AND conname = 'product_stock_store_id_fkey') THEN
        ALTER TABLE product_stock ADD CONSTRAINT product_stock_store_id_fkey
            FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE SET NULL;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'product_suppliers'::regclass AND conname = 'product_suppliers_product_id_fkey') THEN
        ALTER TABLE product_suppliers ADD CONSTRAINT product_suppliers_product_id_fkey
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'shifts'::regclass AND conname = 'shifts_reviewed_by_fkey') THEN
        ALTER TABLE shifts ADD CONSTRAINT shifts_reviewed_by_fkey
            FOREIGN KEY (reviewed_by) REFERENCES users(id);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'shifts'::regclass AND conname = 'shifts_store_id_fkey') THEN
        ALTER TABLE shifts ADD CONSTRAINT shifts_store_id_fkey
            FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE SET NULL;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'shifts'::regclass AND conname = 'shifts_user_id_fkey') THEN
        ALTER TABLE shifts ADD CONSTRAINT shifts_user_id_fkey
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'suppliers'::regclass AND conname = 'suppliers_store_id_fkey') THEN
        ALTER TABLE suppliers ADD CONSTRAINT suppliers_store_id_fkey
            FOREIGN KEY (store_id) REFERENCES stores(id);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'warehouses'::regclass AND conname = 'warehouses_store_id_fkey') THEN
        ALTER TABLE warehouses ADD CONSTRAINT warehouses_store_id_fkey
            FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE SET NULL;
    END IF;
END $$;

COMMIT;

-- ROLLBACK:
-- ALTER TABLE import_jobs DROP CONSTRAINT IF EXISTS import_jobs_store_id_fkey;
-- ALTER TABLE import_jobs DROP CONSTRAINT IF EXISTS import_jobs_user_id_fkey;
-- ALTER TABLE pricing_rules DROP CONSTRAINT IF EXISTS pricing_rules_category_id_fkey;
-- ALTER TABLE pricing_rules DROP CONSTRAINT IF EXISTS pricing_rules_product_id_fkey;
-- ALTER TABLE pricing_rules DROP CONSTRAINT IF EXISTS pricing_rules_store_id_fkey;
-- ALTER TABLE product_stock DROP CONSTRAINT IF EXISTS product_stock_product_id_fkey;
-- ALTER TABLE product_stock DROP CONSTRAINT IF EXISTS product_stock_store_id_fkey;
-- ALTER TABLE product_suppliers DROP CONSTRAINT IF EXISTS product_suppliers_product_id_fkey;
-- ALTER TABLE shifts DROP CONSTRAINT IF EXISTS shifts_reviewed_by_fkey;
-- ALTER TABLE shifts DROP CONSTRAINT IF EXISTS shifts_store_id_fkey;
-- ALTER TABLE shifts DROP CONSTRAINT IF EXISTS shifts_user_id_fkey;
-- ALTER TABLE suppliers DROP CONSTRAINT IF EXISTS suppliers_store_id_fkey;
-- ALTER TABLE warehouses DROP CONSTRAINT IF EXISTS warehouses_store_id_fkey;
