-- Migration: 052_first_install_hardening.sql
-- Description: First-install hardening — force rotation of untouched seed
-- credentials, align role/user data defects left behind by the legacy
-- rename path (044/045), backfill store-less managers, and enforce
-- case-insensitive store name uniqueness.
--
-- There is no first-run/setup endpoint: install = migrate + first login. The
-- six accounts seeded by 000_squash.sql all ship with password 'admin123' and
-- must_change_password = false (050 DEFAULT), so nothing forced the operator
-- off the published default credential. Step 1 closes that gap.
--
-- 1. must_change_password on un-rotated seed accounts
--    crypt('admin123', u.password_hash) reuses the stored bcrypt salt, so the
--    equality test re-verifies the row against the seed password itself rather
--    than matching on username alone. Accounts whose password already changed
--    fail the test and are left alone; re-running the migration is a no-op.
--    The 428 gate (middleware.NewModularAuthMiddleware) then forces rotation on
--    the next protected request. Self-service rotation for already-unflagged
--    accounts ships separately (docs/design/first-install-and-seeder-revamp-plan.md).
--
-- 2. finance role is_system
--    044 created finance without is_system, so databases upgraded through the
--    legacy rename path let an operator edit/delete the role while a fresh
--    install (000_squash.sql:1250-1257) does not.
--
-- 3. Realigned seed emails
--    045 renamed usernames but not emails, leaving 'manager' on
--    admin@retailpos.local, 'supervisor' on manager@retailpos.local and
--    'inventory_staff' on staff@retailpos.local. users_email_key is UNIQUE, so
--    each update is guarded by NOT EXISTS: a real account already holding the
--    target address aborts loudly instead of silently colliding.
--
-- 4. Store-less managers
--    CreateUser rejects a null store_id only for permissions.OperationalRoles
--    (internal/permissions/permissions.go), which omitted manager at the time
--    this migration was written. Those accounts authenticate but then 403 on
--    every protected route via RequireStoreID, including /api/stores, so they
--    cannot self-repair. The paired code change adds manager to
--    OperationalRoles; this backfill repairs rows created before that change.
--
-- 5. stores.name uniqueness
--    GetByName looks up WHERE LOWER(name) = LOWER($1) and the onboarding wizard
--    generates deterministic LOC-<storeId> / <role><storeId> identifiers, but
--    the table has no constraint, so duplicates are possible today. A unique
--    expression index on LOWER(name) matches the lookup's case-insensitive
--    semantics (a plain UNIQUE constraint would not).
--
-- Apply before deploying the binary: step 1 changes login behaviour (HTTP 428).

BEGIN;

-- 1. Force rotation on seed accounts still holding the seed password
UPDATE users u
SET must_change_password = true
WHERE u.username IN ('superadmin', 'manager', 'supervisor', 'cashier', 'inventory_staff', 'finance')
  AND u.password_hash = crypt('admin123', u.password_hash);

-- 2. finance is a system role on every install path
UPDATE roles SET is_system = true
WHERE name = 'finance' AND is_system = false;

-- 3. Realign emails left stale by 045 (guarded: users_email_key is UNIQUE).
--    Order matters: 'supervisor' initially holds manager@retailpos.local, so it
--    must vacate that address before 'manager' can claim it.
UPDATE users u SET email = 'supervisor@retailpos.local'
WHERE u.username = 'supervisor'
  AND u.email = 'manager@retailpos.local'
  AND NOT EXISTS (SELECT 1 FROM users x WHERE x.email = 'supervisor@retailpos.local');

UPDATE users u SET email = 'inventory_staff@retailpos.local'
WHERE u.username = 'inventory_staff'
  AND u.email = 'staff@retailpos.local'
  AND NOT EXISTS (SELECT 1 FROM users x WHERE x.email = 'inventory_staff@retailpos.local');

UPDATE users u SET email = 'manager@retailpos.local'
WHERE u.username = 'manager'
  AND u.email = 'admin@retailpos.local'
  AND NOT EXISTS (SELECT 1 FROM users x WHERE x.email = 'manager@retailpos.local');

-- 4. Repair managers left store-less by the OperationalRoles gap.
--    EXISTS guard: an empty stores table is a no-op, not a NULL store_id.
UPDATE users u
SET store_id = (SELECT s.id FROM stores s WHERE s.is_active ORDER BY s.id LIMIT 1)
WHERE u.store_id IS NULL
  AND u.role_id = (SELECT id FROM roles WHERE name = 'manager')
  AND EXISTS (SELECT 1 FROM stores s WHERE s.is_active);

-- 5. stores.name uniqueness (case-insensitive, matching GetByName).
--    Fail loudly on duplicates: renaming stores silently would corrupt
--    operational data.
DO $$
DECLARE
    dups text;
BEGIN
    SELECT string_agg(quote_literal(name), ', ' ORDER BY name) INTO dups
    FROM stores
    GROUP BY LOWER(name)
    HAVING COUNT(*) > 1;
    IF dups IS NOT NULL THEN
        RAISE EXCEPTION 'stores.name duplicates prevent the unique index: %', dups;
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS stores_name_lower_key ON stores (LOWER(name));

-- Migration registration
INSERT INTO schema_migrations (filename) VALUES ('052_first_install_hardening.sql')
ON CONFLICT (filename) DO NOTHING;

COMMIT;

-- ROLLBACK:
-- DROP INDEX IF EXISTS stores_name_lower_key;
-- UPDATE users SET must_change_password = false
--   WHERE username IN ('superadmin', 'manager', 'supervisor', 'cashier', 'inventory_staff', 'finance');
-- UPDATE roles SET is_system = false WHERE name = 'finance';
-- UPDATE users SET email = 'admin@retailpos.local'
--   WHERE username = 'manager' AND email = 'manager@retailpos.local'
--     AND NOT EXISTS (SELECT 1 FROM users x WHERE x.email = 'admin@retailpos.local');
-- UPDATE users SET email = 'manager@retailpos.local'
--   WHERE username = 'supervisor' AND email = 'supervisor@retailpos.local'
--     AND NOT EXISTS (SELECT 1 FROM users x WHERE x.email = 'manager@retailpos.local');
-- UPDATE users SET email = 'staff@retailpos.local'
--   WHERE username = 'inventory_staff' AND email = 'inventory_staff@retailpos.local'
--     AND NOT EXISTS (SELECT 1 FROM users x WHERE x.email = 'staff@retailpos.local');
-- -- Step 4 (manager store backfill) is NOT reversible: a manager stranded by the
-- -- OperationalRoles gap and a manager legitimately assigned a store are
-- -- indistinguishable after the fact. Restore users.store_id from backup if it
-- -- must be undone.
